#_____options_______#
host = 'xxx.xxx.xxx.xxx'
user = 'userlogin'
password = 'userpassword'
db = 'asteriskcdrdb'

version = 'Asterisk Dashboard 3.0'
